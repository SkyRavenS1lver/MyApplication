package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class SampleAdapter extends FragmentStateAdapter {
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0){
            FirstFragment fragment1 = new FirstFragment();
            return fragment1;
        }
        else(position == 1){
            SecondFragment fragment2 = new SecondFragment();
            return fragment2;
        }
        return null;
    }
    // Banyaknya tab pada nav
    @Override
    public int getItemCount() {
        return 2;
    }
}
